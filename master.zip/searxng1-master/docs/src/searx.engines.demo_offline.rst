.. _demo offline engine:

===================
Demo Offline Engine
===================

.. automodule:: searx.engines.demo_offline
  :members:

