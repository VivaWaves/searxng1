.. _redis db:

========
Redis DB
========

.. automodule:: searx.redisdb
  :members:
