.. _searx.locales:

=======
Locales
=======

.. contents:: Contents
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.locales
  :members:


SearXNG's locale codes
======================

.. automodule:: searx.sxng_locales
  :members:
