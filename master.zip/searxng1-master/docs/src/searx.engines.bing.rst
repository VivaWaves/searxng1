.. _bing engines:

============
Bing Engines
============

.. contents:: Contents
   :depth: 2
   :local:
   :backlinks: entry


.. _bing web engine:

Bing WEB
========

.. automodule:: searx.engines.bing
  :members:

.. _bing images engine:

Bing Images
===========

.. automodule:: searx.engines.bing_images
  :members:

.. _bing videos engine:

Bing Videos
===========

.. automodule:: searx.engines.bing_videos
  :members:

.. _bing news engine:

Bing News
=========

.. automodule:: searx.engines.bing_news
  :members:
