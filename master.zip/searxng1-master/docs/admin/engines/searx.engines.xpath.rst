.. _xpath engine:

============
XPath Engine
============

.. automodule:: searx.engines.xpath
  :members:

